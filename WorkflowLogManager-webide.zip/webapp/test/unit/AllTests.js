sap.ui.define([
	"workflowReport/workflowReport/test/unit/controller/View1.controller"
], function () {
	"use strict";
});